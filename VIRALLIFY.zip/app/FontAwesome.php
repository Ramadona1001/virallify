<?php

function fontAWS()
{
    return [
        "fa-brands fa-facebook",
        "fa-brands fa-instagram",
        "fa-brands fa-twitter",
        "fa-brands fa-youtube",
        "fa-brands fa-linkedin",
        "fa-brands fa-whatsapp",
        "fa-brands fa-snapchat",
        "fa-brands fa-behance",
        "fa-brands fa-tiktok",
        "fa-brands fa-vimeo",
        "fa fa-phone",
        "fa fa-envelope",
        "fa fa-address-book",
    ];
}