<?php

namespace Translates\Models;
use Illuminate\Database\Eloquent\Model;

class Translate extends Model
{
    protected $table = 'language_translates';
}
