<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <div class="text-sm-right d-none d-sm-block">
                  &copy;
                  <script>
                    document.write(new Date().getFullYear());
                  </script>
                  {{ $main_settings->name }} - {{ transWord('Made With ♥') }}
                </div>
            </div>
        </div>
    </div>
</footer>