<footer class="app_footer">
    <p class="mb-0">2020 Elite Home All rights reserved.</p>
</footer>