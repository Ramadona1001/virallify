<meta charset="UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="csrf-token" content="{{ csrf_token() }}">
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="{{asset('sales-dashboard/assets/css/bootstrap.min.css')}}" />
<link rel="stylesheet" href="{{asset('sales-dashboard/assets/css/intlTelInput.css')}}" />
<link rel="stylesheet" href="{{asset('sales-dashboard/assets/css/main.css')}}" />
<link rel="stylesheet" href="{{asset('sales-dashboard/assets/css/custom.css')}}" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

@yield('styles')
